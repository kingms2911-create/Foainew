# Agent Room: Phase 1 (sab ek Vercel dashboard me)

## Features
- **Leads:** local businesses (OpenStreetMap, free) + optional Reddit -> AI score 1-10 (hot/warm/cold), filter, search, CSV, status/phone, pitch + 3 follow-ups, "Send via WhatsApp" (wa.me, aap khud Send dabate ho), "Free audit PDF".
- **Content:** "Write article" (SEO, meta, FAQ schema, image), WordPress auto-post (bots), Reel/Short/Ad script, **Competitor spy** (gaps + better outline), **Course** (syllabus, lesson scripts, workbooks).
- **Video Studio:** script -> scenes -> AI images -> free Microsoft voice -> 9:16 video (browser me record hota hai).
- **B2B audit:** prospect ki website ka on-page audit + proposal PDF.
- **Freemium:** sign-up par 10 free credits (har tool ki cost alag), kaam fail ho to credits wapas.

## Login kaise kaam karta hai (ADMIN_KEY hata diya)
- **Open mode (default):** `SUPABASE_ANON_KEY` khali = koi login nahi. **Jiske paas link hai wo sab use kar sakta hai** (aapka AI quota, leads, WordPress). Sirf testing ke liye.
- **Sign-in mode:** `SUPABASE_ANON_KEY` + `ADMIN_EMAILS` daalo. Email + password se login; aapki email = owner (sab kuch, free); baaki users sirf tools (credits se), leads nahi dikhte.
  Supabase -> Authentication -> Providers -> Email: "Confirm email" ON rakho (free credits ka misuse kam hota hai).
  `CRON_SECRET` bhi daalo, warna roz ka auto-run band rehta hai.

## AI (OmniRoute)
`OMNIROUTE_BASE_URL` = aapke OmniRoute ka public `https://.../v1` (localhost Vercel se nahi dikhta), `OMNIROUTE_API_KEY` = uske API Keys page ki gateway key, `OMNIROUTE_MODEL` = model/combo ka naam (ya `auto`).
Free providers ki limits jaldi lag sakti hain; fail hone par OmniRoute ke fallback combos use karo.

## Zaroori baatein
- Video browser me banta hai: utni der lagti hai jitni video ki length, screen on + tab khula rakho. Chrome/Android aksar WebM deta hai.
- Microsoft voice unofficial hai; 403 aaye to `EDGE_TTS_CHROMIUM_VERSION` set karo.
- WhatsApp: har message aap khud bhejte ho; phir bhi unsolicited message report ho to ban ho sakta hai. Opt-out line + kam volume.
- OpenStreetMap: data "© OpenStreetMap contributors"; coverage shehar ke hisaab se alag, chhoti dukaano ka phone aksar missing. `OSM_USER_AGENT` me email daalo.
- Competitor spy / audit sirf public pages padhte hain, robots.txt maante hain. Audit PDF me sirf Latin text (Hindi "?" ban jata hai).
- Reddit ab optional hai (approval chahiye). Google Places hata diya (terms).
- WordPress FAQ schema (script tag) tabhi bachta hai jab WP user Administrator ho.

## Setup
1. Supabase SQL Editor me `supabase/schema.sql` run karo (dobara chalana safe).
2. Vercel Environment Variables: `.env.example` dekho. Minimum: SUPABASE_URL, SUPABASE_SERVICE_KEY, OMNIROUTE_BASE_URL (+KEY), BUSINESS_CONTEXT, OSM_USER_AGENT.
3. Redeploy. Pehle Write article, phir Leads (gyms + shehar), phir Video Studio test karo.

## Rank Math score (90+?) — seedhi baat
**Koi guarantee nahi.** Rank Math ka asli score WordPress editor me article kholne par uska plugin calculate karta hai; hum use yahan se measure nahi kar sakte.
System ye basics khud theek karta hai: focus keyword title, meta description, URL, intro ke pehle sentence aur 1+ heading me; title me number/power word; 800+ words; alt text wali 2 images (featured + beech me); table of contents; ek real external link (Wikipedia) aur aapki site ke purane posts se internal links; chhote paragraphs; FAQ + schema.
Dashboard har article ka apna checklist dikhata hai (kya pass, kya missing).

**Zaroori (warna focus keyword Rank Math tak pahunchta hi nahi):** WordPress REST se Rank Math ke fields tabhi save hote hain jab wo register hon; warna WordPress chupchap ignore kar deta hai.
WordPress me "Code Snippets" plugin se ya `functions.php` me ye daalo (sirf ek baar):

```php
add_action('init', function () {
  foreach (['rank_math_title', 'rank_math_description', 'rank_math_focus_keyword'] as $key) {
    register_post_meta('post', $key, [
      'show_in_rest' => true, 'single' => true, 'type' => 'string',
      'auth_callback' => function ($allowed, $meta_key, $post_id) { return current_user_can('edit_post', $post_id); },
    ]);
  }
});
```
Board me article ke baad likha aata hai "Rank Math fields: saved" ya "NOT saved".

**Kya score kam rakh sakta hai:** nayi site par internal links nahi milte; keyword density kabhi 0.8-1.8% se bahar; chhote topics par 800 words kam; Rank Math ke kuch tests (jaise TOC, title sentiment) alag tareeke se check hote hain. Pehle 3-4 articles kholke dekho kitna score aata hai, phir batao kya kam hai.

## Phone band ho to kya chalta hai?
- **Server pe chalta hai (phone off ho sakta hai):** bots ki queue (WordPress auto-post, lead search/scoring). Bas koi use "jagaye": Vercel ka cron roz 1 baar, ya `docs/keep-running.yml` (GitHub Actions, har 10 minute) - usse bina phone ke poora kaam hota rehta hai.
- **Browser pe chalta hai (page khula rakho):** "Run now" ka loop, Write article, Course, Competitor spy, Video render (video me screen on + tab foreground zaroori).

## Roz 24 articles (har ghante 1)
Settings me: **Site topic** = ek hi niche, **Articles per day** = 24, **One article every N minutes** = 60 (ya "Preset" button). Auto-publish OFF rakho (draft) jab tak quality na dekh lo.
Chalne ke liye server ko har 10 minute jagana hoga: `docs/keep-running.yml` (GitHub Actions). Manager har ghante sirf 1 naya topic shuru karta hai, ek saath 3 se zyada articles beech me nahi rakhta, aur fail hone par bhi roz ke limit se 6 se zyada topics nahi banata.
- **AI quota:** ek article me kareeb 12-13 AI calls lagti hain. 24/day = lagbhag 300 calls roz. Free Gemini/OmniRoute providers ki limit isse kam ho sakti hai; tab article ruk-ruk ke banenge ya kam banenge.
- **Google ka risk:** Google "scaled content abuse" policy me bahut sa content bina asli value ke banana (chahe AI se ya insaan se) spam maanta hai; site ki ranking gir sakti hai ya index se hat sakti hai. Isliye: ek niche, draft + review, pehle 3-6/day se shuru, Search Console me indexing dekhte raho, phir badhao.

## Assistant (chat, Grok/ChatGPT jaisa)
Pehla tab "Assistant" hai. Usse kuch bhi poocho ya bolo "SIP pe article likh do" / "Jaipur ke gyms dhundo": wo sahi tool khol deta hai, form pehle se bhara hua; aap **tap karke chalate ho** (credits aur quota aapke control me). Owner ko leads aur WordPress queue wale actions bhi milte hain.
- Ye **live internet ya X/news nahi dekhta** (Grok ki tarah real-time nahi). Aaj ki khabar/daam ke liye wo khud mana karega.
- Chat history sirf aapke browser me save hoti hai (Clear chat se hatti hai). Streaming nahi hai: jawab poora aane ke baad dikhta hai.
- Regular users ke liye har message 1 credit (`CREDIT_COSTS=...,chat:1` se badlo; 0 matlab free).

## OmniRoute lagane ke steps
1. OmniRoute ko aisi jagah chalao jo internet se dikhe (apna server/VPS/Railway, HTTPS). Localhost ya phone par chalega to Vercel use nahi dekh payega.
2. OmniRoute dashboard me ek API key banao.
3. Vercel me: `OMNIROUTE_BASE_URL=https://aapka-host/v1`, `OMNIROUTE_API_KEY=...`, `OMNIROUTE_MODEL=auto` (ya koi model/combo ka naam). Redeploy.
4. Dashboard -> Settings -> **Test AI connection**: chale to "Working" dikhega aur aapke OmniRoute ke model names ki list, usme se naam copy karke `OMNIROUTE_MODEL` me daalo.
Free providers dheere ya limit wale ho sakte hain; Vercel ek call ko ~45 second se zyada nahi deta (`LLM_TIMEOUT_MS`).

## OmniRoute on Render (free)
- Free instance ~15 minute idle ke baad so jata hai; pehli request 50+ second leti hai, aur Vercel 60 second se zyada nahi rukta. `docs/keep-running.yml` har 10 minute OmniRoute ko jagata rehta hai (secret `OMNIROUTE_BASE_URL` daalo).
- Render free me disk permanent nahi hota: restart/redeploy par OmniRoute ki settings, provider connections ya API keys ud sakti hain. Check karo ki OmniRoute apna data kahan rakhta hai; zarurat ho to uske env/database ke options use karo.
- OmniRoute ka dashboard internet par khula hai: strong password rakho aur API key zaroori (require key) ON rakho, warna koi aur aapke providers use kar sakta hai.
