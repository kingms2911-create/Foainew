'use client';
import { useEffect, useState } from 'react';
import { api, price } from '@/lib/clientApi';

export default function SpyTab({ me, onUsed, onNotes, preset }) {
  const [keyword, setKeyword] = useState('');
  const [urls, setUrls] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const [res, setRes] = useState(null);
  const [saved, setSaved] = useState(false);
  useEffect(() => { if (preset?.keyword) { setKeyword(preset.keyword); setUrls((preset.urls || []).join('\n')); } }, [preset]);

  const go = async () => {
    setBusy(true); setErr(''); setRes(null); setSaved(false);
    try { setRes(await api('/api/tools/spy', { keyword, urls: urls.split(/\s+/).filter(Boolean) })); } catch (e) { setErr(e.message); }
    setBusy(false); onUsed();
  };
  const a = res?.analysis;
  const list = (title, items) => items?.length ? <div className="card"><b>{title}</b>{items.map((x, i) => <div key={i}>• {x}</div>)}</div> : null;

  return (
    <div>
      <label>Target keyword</label>
      <input type="text" value={keyword} onChange={(e) => setKeyword(e.target.value)} placeholder="the keyword you want to rank for" />
      <label>Competitor page links (1-3, one per line)</label>
      <textarea rows={3} value={urls} onChange={(e) => setUrls(e.target.value)} placeholder={'https://example.com/their-article'} />
      <p><button className="btn" onClick={go} disabled={busy || keyword.trim().length < 2 || !urls.trim()}>{busy ? 'Reading pages…' : `🕵️ Analyse competitors${price(me, 'spy')}`}</button></p>
      <p className="sub">Reads public pages only and respects robots.txt. The new article is written in original words, never copied.</p>
      {err && <p className="err">{err}</p>}
      {a && (
        <div>
          <div className="card"><b>Angle to win:</b> {a.angle}</div>
          {list('They all cover', a.coverage)}{list('Gaps you can own', a.gaps)}{list('Their weaknesses', a.weaknesses)}{list('Better outline', a.better_outline)}
          {a.errors?.map((e, i) => <p className="err" key={i}>{e}</p>)}
          <p><button className="btn" onClick={() => { onNotes(res.notes); setSaved(true); }}>✅ Use this in "Write article"</button></p>
          {saved && <p className="sub">Saved. Open the “Write article” tab and tick the competitor option.</p>}
        </div>
      )}
    </div>
  );
}
