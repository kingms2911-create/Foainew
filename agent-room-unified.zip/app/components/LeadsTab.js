'use client';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { api, base64ToBlob, downloadBlob } from '@/lib/clientApi';
import { waLink } from '@/lib/phone';

const STATUSES = ['new', 'contacted', 'replied', 'won', 'lost'];
const ICON = { hot: '🔥', warm: '🟠', cold: '🧊' };
const csvCell = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;

export default function LeadsTab({ st, onQueued, preset }) {
  const [leads, setLeads] = useState([]);
  const [err, setErr] = useState('');
  const [busyId, setBusyId] = useState(null);
  const [auditId, setAuditId] = useState(null);
  const [cats, setCats] = useState(['hot', 'warm', 'cold']);
  const [statuses, setStatuses] = useState(STATUSES);
  const [minScore, setMinScore] = useState(1);
  const [q, setQ] = useState('');
  const [bizType, setBizType] = useState('');
  const [bizCity, setBizCity] = useState('');
  const cc = st.config?.countryCode;
  useEffect(() => { if (preset?.type) { setBizType(preset.type); setBizCity(preset.city || ''); } }, [preset]);

  const load = useCallback(async () => {
    try { setLeads((await api('/api/leads')).leads); setErr(''); } catch (e) { setErr(e.message); }
  }, []);
  useEffect(() => { load(); }, [load, st.counts?.done]);

  const patch = (id, fields) => setLeads((all) => all.map((l) => (l.id === id ? { ...l, ...fields } : l)));
  const save = async (l) => {
    try { await api('/api/leads', { id: l.id, fields: { phone: l.phone || '', status: l.status || 'new', notes: l.notes || '' } }, 'PATCH'); } catch (e) { setErr(e.message); }
  };
  const generate = async (l, type) => {
    setBusyId(l.id); setErr('');
    try { patch(l.id, { outreach: (await api('/api/outreach', { id: l.id, type })).outreach }); } catch (e) { setErr(e.message); }
    setBusyId(null);
  };
  const auditLead = async (l) => {
    setAuditId(l.id); setErr('');
    try {
      const r = await api('/api/tools/audit', { company: l.name || l.title, url: l.website });
      downloadBlob(base64ToBlob(r.pdf, 'application/pdf'), `audit-${String(l.name || 'lead').replace(/\W+/g, '-').toLowerCase()}.pdf`);
    } catch (e) { setErr(e.message); }
    setAuditId(null);
  };
  const findBiz = async () => {
    setErr('');
    try {
      await api('/api/tasks', { type: 'leads', payload: { query: `${bizType.trim()} in ${bizCity.trim()}` } });
      onQueued();
    } catch (e) { setErr(e.message); }
  };
  const scan = async () => {
    setErr('');
    try { await api('/api/tasks', { type: 'leadscan' }); onQueued(); } catch (e) { setErr(e.message); }
  };

  const view = useMemo(() => leads.filter((l) => {
    const cat = l.category || 'cold';
    if (!cats.includes(cat)) return false;
    if (!statuses.includes(l.status || 'new')) return false;
    if (l.score && l.score < minScore) return false;
    if (q && !`${l.title || l.name} ${l.intent_summary || ''} ${l.username || ''}`.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  }), [leads, cats, statuses, minScore, q]);

  const exportCsv = () => {
    const cols = ['created_at', 'source', 'name', 'city', 'address', 'username', 'subreddit', 'title', 'url', 'phone', 'website', 'score', 'category', 'status', 'intent_summary', 'keyword', 'notes'];
    const csv = [cols.join(','), ...view.map((l) => cols.map((c) => csvCell(l[c])).join(','))].join('\n');
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
    a.download = 'leads.csv'; a.click();
  };
  const toggle = (list, setList, v) => setList(list.includes(v) ? list.filter((x) => x !== v) : [...list, v]);
  const count = (cat) => leads.filter((l) => l.category === cat).length;

  return (
    <div>
      <h2 className="h2">Find local businesses (free, OpenStreetMap)</h2>
      <div className="grid2">
        <div><label>Business type</label><input type="text" value={bizType} onChange={(e) => setBizType(e.target.value)} placeholder="e.g. gyms, dentists, cafes" /></div>
        <div><label>City</label><input type="text" value={bizCity} onChange={(e) => setBizCity(e.target.value)} placeholder="e.g. Jaipur" /></div>
      </div>
      <p><button className="btn" onClick={findBiz} disabled={bizType.trim().length < 2 || bizCity.trim().length < 2}>🗺️ Find businesses</button></p>
      <p className="sub">Needs BUSINESS_CONTEXT in Vercel so the AI can score fit. Many small shops have no phone on the map, so some leads will have no number.</p>
      {!st.config?.leadsReady && <p className="sub">Reddit scanning is off (it needs approved Reddit keys). Business search above works without any key.</p>}
      <div className="stats">
        <div className="stat"><b>{leads.length}</b><span>Total</span></div>
        <div className="stat"><b>{count('hot')}</b><span>🔥 Hot</span></div>
        <div className="stat"><b>{count('warm')}</b><span>🟠 Warm</span></div>
      </div>
      <div className="row">
        {st.config?.leadsReady && <button className="btn" onClick={scan}>🔎 Scan Reddit now</button>}
        <button className="btn ghost" onClick={exportCsv}>⬇️ Export CSV</button>
      </div>
      {err && <p className="err">{err}</p>}

      <div className="chips">
        {['hot', 'warm', 'cold'].map((c) => <button key={c} className={`tab ${cats.includes(c) ? 'on' : ''}`} onClick={() => toggle(cats, setCats, c)}>{ICON[c]} {c}</button>)}
        {STATUSES.map((s) => <button key={s} className={`tab ${statuses.includes(s) ? 'on' : ''}`} onClick={() => toggle(statuses, setStatuses, s)}>{s}</button>)}
      </div>
      <div className="grid2">
        <div><label>Min score: {minScore}</label><input type="range" min="1" max="10" value={minScore} onChange={(e) => setMinScore(Number(e.target.value))} /></div>
        <div><label>Search</label><input type="text" value={q} onChange={(e) => setQ(e.target.value)} placeholder="title, summary, user" /></div>
      </div>
      <p className="sub">Reddit people have no phone number. Business phones come from OpenStreetMap when mapped. Without a number the WhatsApp button opens a pick-a-contact chat. You tap Send yourself, nothing is automated.</p>

      {view.length ? view.map((l) => (
        <details className="card" key={l.id}>
          <summary>
            <span className={`badge ${l.category || 'cold'}`}>{l.score ? `${l.score}/10` : '—'}</span>{' '}
            {(l.title || l.name || '').slice(0, 80)}
          </summary>
          <p>{l.intent_summary}</p>
          <small>{l.username ? `u/${l.username} · r/${l.subreddit} · ` : ''}{l.keyword}{l.source === 'osm' || !l.url ? ` · ${l.address || ''}` : ''}</small><br />
          {l.url && <a href={l.url} target="_blank" rel="noreferrer">{l.source === 'osm' ? 'Open on OpenStreetMap' : 'Open post'}</a>}
          {l.phone && <> <a href={`tel:${l.phone}`}>Call</a></>}
          {l.website && <> <a href={l.website} target="_blank" rel="noreferrer">Website</a></>}
          {l.website && <p><button className="btn small ghost" disabled={auditId === l.id} onClick={() => auditLead(l)}>{auditId === l.id ? 'Auditing…' : '📄 Free audit PDF'}</button></p>}
          <div className="grid2">
            <div><label>Phone (with country code)</label><input type="text" value={l.phone || ''} onChange={(e) => patch(l.id, { phone: e.target.value })} /></div>
            <div><label>Status</label><select value={l.status || 'new'} onChange={(e) => patch(l.id, { status: e.target.value })}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select></div>
          </div>
          <p><button className="btn small" onClick={() => save(l)}>💾 Save</button></p>

          {l.outreach?.pitch ? (
            <div>
              <label>Pitch (edit if needed)</label>
              <textarea rows={4} value={l.outreach.pitch} onChange={(e) => patch(l.id, { outreach: { ...l.outreach, pitch: e.target.value } })} />
              <a className="btn small" href={waLink(l.phone, l.outreach.pitch, cc)} target="_blank" rel="noreferrer">📲 Send via WhatsApp</a>
              {(l.outreach.followups || []).map((f, i) => (
                <div key={i}>
                  <label>Follow-up {i + 1} (day {f.day})</label>
                  <textarea rows={3} value={f.text} onChange={(e) => patch(l.id, { outreach: { ...l.outreach, followups: l.outreach.followups.map((x, j) => (j === i ? { ...x, text: e.target.value } : x)) } })} />
                  <a className="btn small ghost" href={waLink(l.phone, f.text, cc)} target="_blank" rel="noreferrer">📲 Send follow-up {i + 1}</a>
                </div>
              ))}
            </div>
          ) : (
            <p>
              <button className="btn small" disabled={busyId === l.id} onClick={() => generate(l, 'service')}>{busyId === l.id ? 'Writing…' : '✨ Service pitch + follow-ups'}</button>{' '}
              <button className="btn small ghost" disabled={busyId === l.id} onClick={() => generate(l, 'course')}>🎓 Course pitch</button>
            </p>
          )}
        </details>
      )) : <p className="empty">No leads yet. Find businesses above.</p>}
      <p className="sub">Business data © OpenStreetMap contributors (ODbL).</p>
    </div>
  );
}
