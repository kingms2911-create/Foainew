'use client';
import { useEffect, useState } from 'react';
import { api, downloadBlob, price, sleep } from '@/lib/clientApi';

export default function CourseTab({ me, onUsed, preset }) {
  const [f, setF] = useState({ topic: '', audience: '', level: 'beginner', modules: 4, lessons: 3 });
  const [status, setStatus] = useState('');
  const [err, setErr] = useState('');
  const [course, setCourse] = useState(null);
  const set = (k, v) => setF((x) => ({ ...x, [k]: v }));
  useEffect(() => { if (preset?.topic) setF((x) => ({ ...x, topic: preset.topic, audience: preset.audience || x.audience })); }, [preset]);
  const pause = () => sleep(me?.config?.provider === 'gemini' ? 4000 : 500);

  const go = async () => {
    setErr(''); setCourse(null);
    try {
      setStatus('Designing the syllabus…');
      const s = await api('/api/tools/course', { step: 'syllabus', ...f });
      onUsed();
      const done = { ...s.syllabus, modules: [] };
      for (let mi = 0; mi < s.syllabus.modules.length; mi++) {
        const module = s.syllabus.modules[mi];
        const lessons = [];
        for (let li = 0; li < module.lessons.length; li++) {
          setStatus(`Module ${mi + 1}/${s.syllabus.modules.length}, lesson ${li + 1}/${module.lessons.length}…`);
          const r = await api('/api/tools/course', { step: 'lesson', ticket: s.ticket, course: s.syllabus, module, lesson: module.lessons[li], audience: f.audience, level: f.level });
          lessons.push({ ...module.lessons[li], script: r.text });
          await pause();
        }
        setStatus(`Module ${mi + 1}: workbook…`);
        const w = await api('/api/tools/course', { step: 'workbook', ticket: s.ticket, course: s.syllabus, module });
        done.modules.push({ ...module, lessons, workbook: w.text });
        await pause();
      }
      setCourse(done);
    } catch (e) { setErr(e.message); }
    setStatus(''); onUsed();
  };

  const markdown = (c) => [`# ${c.title}`, `*${c.subtitle}*`, '', `**Outcome:** ${c.outcome}`, '',
    ...c.modules.flatMap((m, i) => [`## Module ${i + 1}: ${m.title}`, `*Goal: ${m.goal}*`, '', ...m.lessons.flatMap((l, j) => [`### Lesson ${i + 1}.${j + 1}: ${l.title}`, l.script, '']), `### Workbook: Module ${i + 1}`, m.workbook, ''])].join('\n');

  return (
    <div>
      <label>Course topic</label><input type="text" value={f.topic} onChange={(e) => set('topic', e.target.value)} placeholder="e.g. Instagram marketing for small shops" />
      <label>Who is it for?</label><input type="text" value={f.audience} onChange={(e) => set('audience', e.target.value)} placeholder="e.g. shop owners with no marketing experience" />
      <div className="grid2">
        <div><label>Level</label><select value={f.level} onChange={(e) => set('level', e.target.value)}><option>beginner</option><option>intermediate</option><option>advanced</option></select></div>
        <div><label>Modules: {f.modules} · Lessons each: {f.lessons}</label>
          <input type="range" min="2" max="6" value={f.modules} onChange={(e) => set('modules', Number(e.target.value))} />
          <input type="range" min="2" max="5" value={f.lessons} onChange={(e) => set('lessons', Number(e.target.value))} /></div>
      </div>
      <p><button className="btn" onClick={go} disabled={!!status || f.topic.trim().length < 3 || f.audience.trim().length < 3}>{`🎓 Generate course${price(me, 'course')}`}</button></p>
      <p className="sub">Syllabus, a spoken script for every lesson and a workbook per module. It takes a few minutes; keep this page open.</p>
      {status && <p className="sub">{status}</p>}
      {err && <p className="err">{err}</p>}
      {course && (
        <div>
          <div className="card"><b>{course.title}</b><br /><small>{course.outcome}</small>
            {course.modules.map((m, i) => <div key={i}>Module {i + 1}: {m.title} ({m.lessons.length} lessons)</div>)}</div>
          <p><button className="btn" onClick={() => downloadBlob(new Blob([markdown(course)], { type: 'text/markdown' }), 'course.md')}>⬇️ Download course (.md)</button></p>
        </div>
      )}
    </div>
  );
}
