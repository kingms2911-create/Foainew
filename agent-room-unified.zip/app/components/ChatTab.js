'use client';
import { useEffect, useRef, useState } from 'react';
import { api } from '@/lib/clientApi';

const LABELS = {
  write_article: (a) => `Write article: “${a.topic}”`,
  make_script: (a) => `Make a ${a.kind || 'reel'} script: “${a.product}”`,
  competitor_spy: (a) => `Analyse competitors for “${a.keyword}”`,
  build_course: (a) => `Build course: “${a.topic}”`,
  audit_site: (a) => `Audit ${a.company || a.url}`,
  find_leads: (a) => `Find ${a.type} in ${a.city}`,
  queue_wordpress_article: (a) => `Queue for WordPress: “${a.topic}”`,
};
const IDEAS = ['Write an article about SIP for beginners', 'Make a reel script for my gym', 'Audit my website', 'Explain GST in simple Hinglish'];

export default function ChatTab({ me, onUsed, onAction }) {
  const key = `ar_chat_${me.email}`;
  const [msgs, setMsgs] = useState([]);
  const [text, setText] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const end = useRef(null);

  useEffect(() => { try { setMsgs(JSON.parse(localStorage.getItem(key) || '[]')); } catch { setMsgs([]); } }, [key]);
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }); }, [msgs, busy]);
  const store = (next) => { setMsgs(next); try { localStorage.setItem(key, JSON.stringify(next.slice(-60))); } catch { /* storage full */ } };

  const send = async (override) => {
    const content = (override ?? text).trim();
    if (!content || busy) return;
    const next = [...msgs, { role: 'user', content }];
    store(next); setText(''); setErr(''); setBusy(true);
    try {
      const r = await api('/api/chat', { messages: next.map(({ role, content: c }) => ({ role, content: c })) });
      store([...next, { role: 'assistant', content: r.reply, action: r.action }]);
    } catch (e) { setErr(e.message); }
    setBusy(false); onUsed();
  };

  return (
    <div>
      {!msgs.length && (
        <div>
          <p className="sub">Ask anything, or tell me what to do: I can open the article, script, video, spy, course, audit and lead tools for you, already filled in. You tap to run.</p>
          <div className="chips">{IDEAS.map((i) => <button key={i} className="tab" onClick={() => send(i)}>{i}</button>)}</div>
        </div>
      )}
      {msgs.map((m, i) => (
        <div className={`chat ${m.role}`} key={i}>
          <div className="chat-bubble">{m.content}</div>
          {m.action && (
            <button className="btn small" onClick={() => onAction(m.action)}>
              ▶ {(LABELS[m.action.name] || (() => m.action.name))(m.action.args)}
            </button>
          )}
        </div>
      ))}
      {busy && <div className="chat assistant"><div className="chat-bubble sub">Thinking…</div></div>}
      {err && <p className="err">{err}</p>}
      <div ref={end} />
      <div className="chat-input">
        <textarea rows={2} value={text} placeholder="Message…" onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }} />
        <button className="btn" onClick={() => send()} disabled={busy || !text.trim()}>Send</button>
      </div>
      <p className="sub">{me.role === 'user' ? `${me.costs?.chat ?? 1} credit per message · ` : ''}No live internet: it can’t know today’s news or prices. <button className="btn small ghost" onClick={() => store([])}>Clear chat</button></p>
    </div>
  );
}
