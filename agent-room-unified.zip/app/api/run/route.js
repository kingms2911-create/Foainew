import { tick } from '@/lib/engine';
import { guard } from '@/lib/session';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
export async function POST(req) {
  const { deny } = await guard(req, { owner: true });
  if (deny) return deny;
  try { return Response.json(await tick()); } catch (e) { return Response.json({ error: e.message }, { status: 500 }); }
}
