import { guard } from '@/lib/session';
import { chat, provider } from '@/lib/llm';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
// Owner-only: checks that the AI connection (OmniRoute / Gemini / OpenRouter) really answers.
export async function GET(req) {
  const { deny } = await guard(req, { owner: true });
  if (deny) return deny;
  const p = provider();
  const model = p === 'omniroute' ? process.env.OMNIROUTE_MODEL || 'auto' : p === 'gemini' ? process.env.GEMINI_MODEL || 'gemini-2.5-flash' : process.env.OPENROUTER_MODEL || 'openai/gpt-4o-mini';
  const out = { provider: p, model, ok: false };
  const t0 = Date.now();
  try { out.sample = (await chat('You are a connection test.', 'Reply with the single word OK.', { max: 30, temperature: 0 })).slice(0, 80); out.ok = true; } catch (e) { out.error = e.message; }
  out.ms = Date.now() - t0;
  if (p === 'omniroute') {
    try {
      const base = process.env.OMNIROUTE_BASE_URL.replace(/\/+$/, '').replace(/\/chat\/completions$/, '');
      const r = await fetch(`${base}/models`, { headers: process.env.OMNIROUTE_API_KEY ? { Authorization: `Bearer ${process.env.OMNIROUTE_API_KEY}` } : {}, signal: AbortSignal.timeout(10000) });
      if (r.ok) out.models = ((await r.json()).data || []).map((m) => m.id).slice(0, 40);
    } catch { /* model list is a bonus */ }
  }
  return Response.json(out);
}
