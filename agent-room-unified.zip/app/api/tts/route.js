import { withTicketHeader } from '@/lib/tools';
import { synthesize } from '@/lib/edgeTts';
export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
const VOICE = /^[a-z]{2,3}-[A-Z]{2}-[A-Za-z]+Neural$/;
export async function POST(req) {
  { const { deny } = await withTicketHeader(req, 'video'); if (deny) return deny; }
  const { text, voice = 'en-IN-NeerjaNeural' } = await req.json();
  if (!text || String(text).length > 1500) return Response.json({ error: 'Text must be 1-1500 characters' }, { status: 400 });
  if (!VOICE.test(voice)) return Response.json({ error: 'Unknown voice' }, { status: 400 });
  let lastErr;
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const audio = await synthesize(String(text), voice);
      return new Response(audio, { headers: { 'Content-Type': 'audio/mpeg', 'Cache-Control': 'no-store' } });
    } catch (e) { lastErr = e; }
  }
  return Response.json({ error: lastErr.message }, { status: 502 });
}
