import { paid } from '@/lib/tools';
import { runAudit } from '@/lib/audit';
import { buildAuditPdf } from '@/lib/auditPdf';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
export const POST = (req) => paid(req, 'audit', async (b) => {
  if (!b.company || !b.url) throw new Error('Add the company name and its website');
  const audit = await runAudit(String(b.url), String(b.company));
  return { audit, pdf: Buffer.from(await buildAuditPdf(audit)).toString('base64') };
});
