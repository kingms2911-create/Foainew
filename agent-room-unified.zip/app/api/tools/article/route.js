import { paid, stepped } from '@/lib/tools';
import { planArticle, writeSection, pollinationsUrl } from '@/lib/articleSteps';
import { addTocAndIds, findReference, seoReport } from '@/lib/seo';
import { esc } from '@/lib/articleSteps';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
// step "plan" charges credits and returns a ticket; step "section" (repeated) needs that ticket.
export async function POST(req) {
  const peek = await req.clone().json().catch(() => ({}));
  if (peek.step === 'section') {
    return stepped(req, 'article', async (b) => {
      const r = await writeSection({ seo: b.seo, extra: b.extra, index: Number(b.index), parts: b.parts || [] });
      if (!r.done) return r;
      const ref = await findReference(b.seo.primary_keyword);
      let html = addTocAndIds(r.html);
      if (ref) html += `\n<p><strong>Further reading:</strong> <a href="${ref.url}" target="_blank" rel="noopener">${esc(ref.title)}</a></p>`;
      const report = seoReport({ seo: b.seo, html, imageAlts: [b.seo.primary_keyword], internalLinks: 0, externalLinks: ref ? 1 : 0 });
      return { ...r, html, report, imageUrl: pollinationsUrl(b.seo.image_prompt || b.seo.title) };
    });
  }
  return paid(req, 'article', async (b) => {
    const topic = String(b.topic || '').trim();
    if (topic.length < 3) throw new Error('Write a topic first');
    return { seo: await planArticle({ topic: { title: topic, keyword: topic }, extra: b.extra }) };
  });
}
