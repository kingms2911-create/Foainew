import { db } from '@/lib/db';
import { guard } from '@/lib/session';
export const dynamic = 'force-dynamic';
const ALLOWED = ['seo', 'leadscan', 'leads', 'topic'];
export async function POST(req) {
  { const { deny } = await guard(req, { owner: true }); if (deny) return deny; }
  const { type, payload = {}, niche = null } = await req.json();
  if (!ALLOWED.includes(type)) return Response.json({ error: 'Unknown task type' }, { status: 400 });
  if (type === 'seo' && !payload.topic?.title) return Response.json({ error: 'Topic is required' }, { status: 400 });
  if (type === 'leads' && String(payload.query || '').trim().length < 5) return Response.json({ error: 'Write the search like "gyms in Jaipur"' }, { status: 400 });
  const { data, error } = await db().from('tasks').insert({ type, niche, payload }).select('id').single();
  if (error) return Response.json({ error: error.message }, { status: 500 });
  return Response.json({ id: data.id });
}
