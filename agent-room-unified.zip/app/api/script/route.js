import { paid } from '@/lib/tools';
import { generateScript } from '@/lib/scripts';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
export const POST = (req) => paid(req, 'script', async (b) => {
  if (!b.product) throw new Error('Product or topic is required');
  return generateScript({ kind: b.kind, product: b.product, audience: b.audience, offer: b.offer });
});
