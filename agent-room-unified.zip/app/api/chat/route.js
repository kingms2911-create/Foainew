import { paid } from '@/lib/tools';
import { askAssistant } from '@/lib/assistant';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;
export const POST = (req) => paid(req, 'chat', (b, user) => askAssistant(b.messages, user.role === 'owner'));
