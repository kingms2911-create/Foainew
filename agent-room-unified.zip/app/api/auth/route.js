import { authEnabled, getUser } from '@/lib/session';
import { ensureAccount, balance } from '@/lib/credits';
export const dynamic = 'force-dynamic';

async function supa(path, body, params = '') {
  const res = await fetch(`${process.env.SUPABASE_URL}/auth/v1/${path}${params}`, {
    method: 'POST', headers: { apikey: process.env.SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify(body), signal: AbortSignal.timeout(15000),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.msg || data.error_description || data.message || `Sign-in error ${res.status}`);
  return data;
}

async function session(data) {
  const me = await getUser(new Request('http://x', { headers: { authorization: `Bearer ${data.access_token}` } }));
  if (!me) throw new Error('Sign-in failed. Please try again.');
  if (me.role === 'user') await ensureAccount(me);
  return { token: data.access_token, refresh: data.refresh_token, email: me.email, role: me.role, credits: await balance(me) };
}

export async function POST(req) {
  if (!authEnabled()) return Response.json({ error: 'Login is not set up (open mode)' }, { status: 400 });
  try {
    const { action, email, password, refresh } = await req.json();
    if (action === 'refresh') return Response.json(await session(await supa('token', { refresh_token: refresh }, '?grant_type=refresh_token')));
    if (!/^\S+@\S+\.\S+$/.test(email || '') || String(password || '').length < 6) return Response.json({ error: 'Enter a valid email and a password of at least 6 characters' }, { status: 400 });
    if (action === 'signup') {
      const data = await supa('signup', { email, password });
      if (data.access_token) return Response.json(await session(data));
      return Response.json({ message: 'Account created. Check your email to confirm it, then sign in.' });
    }
    return Response.json(await session(await supa('token', { email, password }, '?grant_type=password')));
  } catch (e) { return Response.json({ error: e.message }, { status: 401 }); }
}
