'use client';
import { useEffect, useState, useCallback, useRef } from 'react';
import { api, setSession } from '@/lib/clientApi';
import ArticlesTab from './components/ArticlesTab';
import ChatTab from './components/ChatTab';
import ArticleTool from './components/ArticleTool';
import AuditTab from './components/AuditTab';
import CourseTab from './components/CourseTab';
import LeadsTab from './components/LeadsTab';
import SpyTab from './components/SpyTab';
import VideoStudio from './components/VideoStudio';

const COLORS = { manager: '#12263a', topic_finder: '#0f766e', researcher: '#0369a1', seo_researcher: '#4f46e5', writer: '#b45309', editor: '#be185d', publisher: '#15803d', lead_finder: '#7c3aed' };
const initials = (n = '') => n.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
const OWNER_TABS = [['chat', 'Assistant'], ['board', 'Meeting room'], ['auto', 'WordPress auto-post'], ['leads', 'Leads'], ['write', 'Write article'], ['video', 'Video Studio'], ['spy', 'Competitor spy'], ['course', 'Course'], ['audit', 'B2B audit'], ['settings', 'Settings']];
const USER_TABS = OWNER_TABS.filter(([id]) => ['chat', 'write', 'video', 'spy', 'course', 'audit'].includes(id));

function Login({ onDone }) {
  const [mode, setMode] = useState('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true); setErr(''); setMsg('');
    try {
      const d = await api('/api/auth', { action: mode === 'signup' ? 'signup' : 'login', email, password });
      if (d.token) { setSession(d); onDone(); } else setMsg(d.message);
    } catch (e) { setErr(e.message); }
    setBusy(false);
  };
  return (
    <div className="wrap">
      <h1>Agent Room</h1>
      <p className="sub">{mode === 'signup' ? 'Create an account. New accounts get free credits to try every tool.' : 'Sign in to continue.'}</p>
      <input type="text" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" placeholder="Password (6+ characters)" value={password} onChange={(e) => setPassword(e.target.value)} style={{ marginTop: 8 }} />
      {err && <p className="err">{err}</p>}
      {msg && <p className="sub">{msg}</p>}
      <p><button className="btn" onClick={submit} disabled={busy}>{mode === 'signup' ? 'Create account' : 'Sign in'}</button>{' '}
        <button className="btn ghost" onClick={() => { setMode(mode === 'signup' ? 'login' : 'signup'); setErr(''); setMsg(''); }}>{mode === 'signup' ? 'I have an account' : 'Sign up'}</button></p>
    </div>
  );
}

export default function Home() {
  const [me, setMe] = useState(null);
  const [needLogin, setNeedLogin] = useState(false);
  const [st, setSt] = useState(null);
  const [tab, setTab] = useState('chat');
  const [preset, setPreset] = useState(null);
  const [aiTest, setAiTest] = useState(null);
  const [err, setErr] = useState('');
  const [msg, setMsg] = useState('');
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState(null);
  const [studioScript, setStudioScript] = useState(null);
  const [notes, setNotes] = useState('');
  const stopRef = useRef(false);

  const loadMe = useCallback(async () => {
    try { const d = await api('/api/me'); setMe(d); setNeedLogin(false); }
    catch (e) { if (e.status === 401) { setNeedLogin(true); setMe(null); } else setErr(e.message); }
  }, []);
  const loadState = useCallback(async () => {
    try { const d = await api('/api/state'); setSt(d); setForm((f) => f || d.settings); } catch (e) { if (e.status !== 403) setErr(e.message); }
  }, []);

  useEffect(() => { loadMe(); }, [loadMe]);
  const isOwner = me?.role === 'owner';
  useEffect(() => { if (!isOwner) return undefined; loadState(); const t = setInterval(loadState, 10000); return () => clearInterval(t); }, [isOwner, loadState]);

  // Runs the agents step by step until nothing is pending (each call fits Vercel's time limit).
  const run = async () => {
    if (busy) return;
    setBusy(true); setErr(''); setMsg(''); stopRef.current = false;
    let total = 0;
    try {
      for (let i = 0; i < 80 && !stopRef.current; i++) {
        const r = await api('/api/run', {});
        total += r.ran || 0;
        setMsg(`Working… ${total} steps done`);
        await loadState();
        if (!r.pending) break;
      }
      setMsg(stopRef.current ? `Stopped after ${total} steps` : `Finished: ${total} steps done`);
    } catch (e) { setErr(e.message); }
    setBusy(false); loadState();
  };
  const save = async () => { try { await api('/api/settings', form); setErr(''); setMsg('Settings saved'); loadState(); } catch (e) { setErr(e.message); } };
  const openInStudio = (script) => { setStudioScript(script); setTab('video'); };
  const onAction = async (a) => {
    const x = a.args || {};
    if (a.name === 'queue_wordpress_article') {
      try { await api('/api/tasks', { type: 'seo', payload: { topic: { title: x.topic, keyword: x.topic } } }); setTab('auto'); run(); } catch (e) { setErr(e.message); }
      return;
    }
    const to = { write_article: 'write', make_script: 'video', competitor_spy: 'spy', build_course: 'course', audit_site: 'audit', find_leads: 'leads' }[a.name];
    if (to) { setPreset({ nonce: Date.now(), ...x }); setTab(to); }
  };
  const testAi = async () => { setAiTest({ busy: true }); try { setAiTest(await api('/api/ai')); } catch (e) { setAiTest({ ok: false, error: e.message }); } };
  const logout = () => { setSession(null); setMe(null); setSt(null); setNeedLogin(true); };

  if (needLogin) return <Login onDone={loadMe} />;
  if (!me) return <div className="wrap"><h1>Agent Room</h1>{err ? <p className="err">{err}</p> : <p className="sub">Loading…</p>}</div>;

  const tabs = isOwner ? OWNER_TABS : USER_TABS;
  const c = st?.counts || {};
  return (
    <div className="wrap">
      <div className="row">
        <div>
          <h1>Agent Room</h1>
          <p className="sub" style={{ margin: 0 }}>{me.open ? 'Open mode' : me.email} · AI: {{ omniroute: 'OmniRoute', gemini: 'Gemini', openrouter: 'OpenRouter' }[me.config?.provider]}{!isOwner && ` · ${me.credits ?? 0} credits left`}</p>
        </div>
        <div>
          {isOwner && <button className="btn" onClick={busy ? () => { stopRef.current = true; } : run}>{busy ? 'Stop' : 'Run now'}</button>}{' '}
          {me.authEnabled && <button className="btn ghost" onClick={logout}>Log out</button>}
        </div>
      </div>
      {me.open && <p className="note">Open mode: anyone who has this link can use this dashboard, spend your AI quota and see your leads. To turn on sign-in and free credits, set SUPABASE_ANON_KEY and ADMIN_EMAILS in Vercel.</p>}
      {err && <p className="err">{err}</p>}
      {msg && <p className="sub">{msg}</p>}
      {isOwner && st && (
        <div className="stats">
          <div className="stat"><b>{c.pending || 0}</b><span>Waiting</span></div>
          <div className="stat"><b>{c.done || 0}</b><span>Done</span></div>
          <div className="stat"><b>{(c.failed || 0) + (c.rejected || 0)}</b><span>Failed</span></div>
        </div>
      )}
      <div className="tabs">
        {tabs.map(([id, label]) => <button key={id} className={`tab ${tab === id ? 'on' : ''}`} onClick={() => { setPreset(null); setTab(id); }}>{label}</button>)}
      </div>

      {tab === 'chat' && <ChatTab me={me} onUsed={loadMe} onAction={onAction} />}
      {tab === 'board' && isOwner && st && (st.board.length ? st.board.map((m) => (
        <div className="msg" key={m.id}>
          <div className="av" style={{ background: COLORS[m.role] || '#555' }}>{initials(m.agent)}</div>
          <div className={`bub ${m.kind}`}><div className="who">{m.agent} · {new Date(m.created_at).toLocaleString()}</div><p>{m.content}</p></div>
        </div>
      )) : <p className="empty">No messages yet. Tap “Run now” to start the first meeting.</p>)}
      {tab === 'auto' && isOwner && st && <ArticlesTab st={st} onQueued={run} openInStudio={openInStudio} />}
      {tab === 'leads' && isOwner && st && <LeadsTab st={{ ...st, config: me.config }} onQueued={run} preset={preset} />}
      {tab === 'write' && <ArticleTool me={me} onUsed={loadMe} notes={notes} preset={preset} />}
      {tab === 'video' && <VideoStudio me={me} onUsed={loadMe} initialScript={studioScript} preset={preset} />}
      {tab === 'spy' && <SpyTab me={me} onUsed={loadMe} onNotes={setNotes} preset={preset} />}
      {tab === 'course' && <CourseTab me={me} onUsed={loadMe} preset={preset} />}
      {tab === 'audit' && <AuditTab me={me} onUsed={loadMe} preset={preset} />}

      {tab === 'settings' && isOwner && form && (
        <div>
          <label>Publishing mode</label>
          <button className="btn ghost" onClick={() => setForm({ ...form, auto_publish: form.auto_publish === 'true' ? 'false' : 'true' })}>
            {form.auto_publish === 'true' ? 'Auto-publish is ON' : 'Saving as draft (review first)'}
          </button>
          <label>Site topic (one niche, e.g. personal finance for Indians). Empty = random from 20 niches</label>
          <input type="text" value={form.site_niche || ''} onChange={(e) => setForm({ ...form, site_niche: e.target.value })} />
          <label>Articles per day (0 = leads only)</label>
          <input type="number" min="0" max="100" value={form.daily_limit} onChange={(e) => setForm({ ...form, daily_limit: e.target.value })} />
          <label>One article every N minutes (60 = hourly, 0 = as fast as possible)</label>
          <input type="number" min="0" max="1440" value={form.post_interval_minutes || 0} onChange={(e) => setForm({ ...form, post_interval_minutes: e.target.value })} />
          <p><button className="btn small ghost" onClick={() => setForm({ ...form, daily_limit: '24', post_interval_minutes: '60' })}>Preset: 24 per day, one every hour</button></p>
          <label>Daily Reddit lead scan</label>
          <button className="btn ghost" onClick={() => setForm({ ...form, auto_leads: form.auto_leads === 'false' ? 'true' : 'false' })}>
            {form.auto_leads === 'false' ? 'Auto scan is OFF' : 'Auto scan is ON'}
          </button>
          <label>Business searches, run daily (one per line, e.g. gyms in Jaipur)</label>
          <textarea rows={4} placeholder={'gyms in Jaipur\ncafes in Pune'} value={form.lead_queries} onChange={(e) => setForm({ ...form, lead_queries: e.target.value })} />
          <p><button className="btn" onClick={save}>Save settings</button></p>
          <label>AI connection</label>
          <p><button className="btn ghost" onClick={testAi} disabled={aiTest?.busy}>{aiTest?.busy ? 'Testing…' : '🔌 Test AI connection'}</button></p>
          {aiTest && !aiTest.busy && (
            <div className="card">
              <b>{aiTest.ok ? '✅ Working' : '❌ Not working'}</b> · {aiTest.provider} · model: {aiTest.model} {aiTest.ms ? `· ${aiTest.ms} ms` : ''}
              {aiTest.error && <p className="err">{aiTest.error}</p>}
              {aiTest.sample && <p className="sub">Answer: {aiTest.sample}</p>}
              {aiTest.models?.length > 0 && <p className="sub">Models on your OmniRoute (copy one into OMNIROUTE_MODEL): {aiTest.models.join(', ')}</p>}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
